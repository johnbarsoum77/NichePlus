import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Niche Plus - Admin Dashboard</h1>
        <p>Manage sectors, companies, and editorial content</p>
      </header>
      
      <main className="dashboard-container">
        <aside className="sidebar">
          <nav>
            <ul>
              <li className="active"><a href="#dashboard">Dashboard</a></li>
              <li><a href="#sectors">Sectors</a></li>
              <li><a href="#companies">Companies</a></li>
              <li><a href="#editorial">Editorial</a></li>
              <li><a href="#users">Users</a></li>
              <li><a href="#settings">Settings</a></li>
            </ul>
          </nav>
        </aside>
        
        <section className="main-content">
          <div className="dashboard-card">
            <h2>Admin Overview</h2>
            <p>Welcome to the Niche Plus admin dashboard. Here you can manage all aspects of the platform.</p>
            
            <div className="stats-container">
              <div className="stat-card">
                <h3>5</h3>
                <p>Active Sectors</p>
              </div>
              <div className="stat-card">
                <h3>8</h3>
                <p>Featured Companies</p>
              </div>
              <div className="stat-card">
                <h3>24</h3>
                <p>Registered Users</p>
              </div>
              <div className="stat-card">
                <h3>15</h3>
                <p>Bookings This Week</p>
              </div>
            </div>
          </div>
          
          <div className="dashboard-card">
            <h2>Sector Management</h2>
            <div className="action-bar">
              <button className="btn primary">Add New Sector</button>
            </div>
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Sector Name</th>
                  <th>Description</th>
                  <th>Assigned Company</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Travel</td>
                  <td>Exclusive travel experiences curated by Niche Magazine</td>
                  <td>Exclusive Journeys</td>
                  <td>
                    <button className="btn edit">Edit</button>
                    <button className="btn delete">Delete</button>
                  </td>
                </tr>
                <tr>
                  <td>Hotels</td>
                  <td>Luxury accommodations handpicked by our editors</td>
                  <td>Luxe Stays</td>
                  <td>
                    <button className="btn edit">Edit</button>
                    <button className="btn delete">Delete</button>
                  </td>
                </tr>
                <tr>
                  <td>Flights</td>
                  <td>Premium flight services with exclusive benefits</td>
                  <td>Sky Elite</td>
                  <td>
                    <button className="btn edit">Edit</button>
                    <button className="btn delete">Delete</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div className="dashboard-card">
            <h2>Editorial Content</h2>
            <div className="action-bar">
              <button className="btn primary">Add New Editorial</button>
            </div>
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Company</th>
                  <th>Date Added</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Why Niche Chose Exclusive Journeys</td>
                  <td>Exclusive Journeys</td>
                  <td>May 10, 2025</td>
                  <td>
                    <button className="btn edit">Edit</button>
                    <button className="btn delete">Delete</button>
                  </td>
                </tr>
                <tr>
                  <td>The Luxe Stays Experience</td>
                  <td>Luxe Stays</td>
                  <td>May 8, 2025</td>
                  <td>
                    <button className="btn edit">Edit</button>
                    <button className="btn delete">Delete</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;

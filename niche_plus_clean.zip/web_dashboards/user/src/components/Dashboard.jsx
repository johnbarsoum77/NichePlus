import React from 'react';
import './Dashboard.css';

function Dashboard() {
  // Mock data for user dashboard
  const bookings = [
    {
      id: 'booking_1001',
      company: 'Exclusive Journeys',
      service: 'Custom Itinerary Planning',
      date: '2025-06-15',
      status: 'confirmed'
    },
    {
      id: 'booking_1002',
      company: 'Luxe Stays',
      service: 'Luxury Suite',
      date: '2025-07-20',
      status: 'pending'
    }
  ];

  const favorites = [
    {
      id: 'exclusive-journeys',
      name: 'Exclusive Journeys',
      sector: 'Travel'
    },
    {
      id: 'luxe-stays',
      name: 'Luxe Stays',
      sector: 'Hotels'
    }
  ];

  const editorsPicks = [
    {
      id: 'pick_1',
      title: 'Summer Escapes',
      description: 'Our curated selection of the most exclusive summer destinations for 2025.',
      image: 'https://example.com/summer-escapes.jpg'
    },
    {
      id: 'pick_2',
      title: 'Luxury Dining',
      description: 'Experience culinary excellence with our handpicked restaurant recommendations.',
      image: 'https://example.com/luxury-dining.jpg'
    }
  ];

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Welcome to Niche Plus</h1>
        <p>Your premium concierge and booking dashboard</p>
      </header>

      <section className="dashboard-section">
        <h2>Your Bookings</h2>
        <div className="bookings-list">
          {bookings.map(booking => (
            <div key={booking.id} className="booking-card">
              <div className="booking-header">
                <h3>{booking.company}</h3>
                <span className={`status status-${booking.status}`}>{booking.status}</span>
              </div>
              <p className="booking-service">{booking.service}</p>
              <p className="booking-date">Date: {booking.date}</p>
              <button className="details-button">View Details</button>
            </div>
          ))}
        </div>
      </section>

      <section className="dashboard-section">
        <h2>Your Favorites</h2>
        <div className="favorites-list">
          {favorites.map(favorite => (
            <div key={favorite.id} className="favorite-card">
              <h3>{favorite.name}</h3>
              <p>{favorite.sector}</p>
              <button className="view-button">View Profile</button>
            </div>
          ))}
        </div>
      </section>

      <section className="dashboard-section editors-picks">
        <h2>Editor's Picks</h2>
        <div className="picks-list">
          {editorsPicks.map(pick => (
            <div key={pick.id} className="pick-card">
              <div className="pick-image-placeholder"></div>
              <div className="pick-content">
                <h3>{pick.title}</h3>
                <p>{pick.description}</p>
                <button className="read-more-button">Read More</button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Dashboard;

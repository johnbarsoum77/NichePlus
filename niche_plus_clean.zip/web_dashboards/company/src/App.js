import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Niche Plus - Company Dashboard</h1>
        <p>Manage your profile, services, and bookings</p>
      </header>
      
      <main className="dashboard-container">
        <aside className="sidebar">
          <nav>
            <ul>
              <li className="active"><a href="#profile">Profile</a></li>
              <li><a href="#services">Services</a></li>
              <li><a href="#bookings">Bookings</a></li>
              <li><a href="#gallery">Gallery</a></li>
              <li><a href="#settings">Settings</a></li>
            </ul>
          </nav>
        </aside>
        
        <section className="main-content">
          <div className="dashboard-card">
            <h2>Welcome to your Company Dashboard</h2>
            <p>This is where you can manage your Niche Plus presence, respond to bookings, and update your services.</p>
            
            <div className="stats-container">
              <div className="stat-card">
                <h3>3</h3>
                <p>Pending Bookings</p>
              </div>
              <div className="stat-card">
                <h3>12</h3>
                <p>Total Bookings</p>
              </div>
              <div className="stat-card">
                <h3>4.9</h3>
                <p>Rating</p>
              </div>
            </div>
          </div>
          
          <div className="dashboard-card">
            <h2>Recent Booking Requests</h2>
            <table className="bookings-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Service</th>
                  <th>Customer</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>May 15, 2025</td>
                  <td>Custom Itinerary Planning</td>
                  <td>John Smith</td>
                  <td><span className="status pending">Pending</span></td>
                  <td>
                    <button className="btn accept">Accept</button>
                    <button className="btn decline">Decline</button>
                  </td>
                </tr>
                <tr>
                  <td>May 14, 2025</td>
                  <td>Private Guided Tour</td>
                  <td>Emma Johnson</td>
                  <td><span className="status pending">Pending</span></td>
                  <td>
                    <button className="btn accept">Accept</button>
                    <button className="btn decline">Decline</button>
                  </td>
                </tr>
                <tr>
                  <td>May 12, 2025</td>
                  <td>Luxury Transportation</td>
                  <td>Michael Brown</td>
                  <td><span className="status confirmed">Confirmed</span></td>
                  <td>
                    <button className="btn details">View Details</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;

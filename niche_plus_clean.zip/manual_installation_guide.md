# Niche Plus App - Manual Installation Guide

This guide provides step-by-step instructions for manually installing all prerequisites and running the Niche Plus app.

## Prerequisites Installation

### 1. Install Node.js
1. Download Node.js LTS version from https://nodejs.org/
2. Run the installer
3. **Important:** Check the box that says "Add to PATH" during installation
4. Verify installation by opening Command Prompt and typing:
   ```
   node --version
   npm --version
   ```

### 2. Install Python (Required for Backend Only)
1. Download Python 3.11 from https://www.python.org/downloads/
2. Run the installer
3. **Important:** Check the box that says "Add Python to PATH" during installation
4. Verify installation by opening Command Prompt and typing:
   ```
   python --version
   ```

## Setting Up the Application

### 1. Set Up Web Dashboards

#### User Dashboard
1. Open Command Prompt
2. Navigate to the user dashboard directory:
   ```
   cd path\to\niche_plus\web_dashboards\user
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the user dashboard:
   ```
   npm start
   ```
5. The dashboard will open in your browser at http://localhost:3000

#### Company Dashboard
1. Open Command Prompt
2. Navigate to the company dashboard directory:
   ```
   cd path\to\niche_plus\web_dashboards\company
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the company dashboard:
   ```
   npm start -- --port 3001
   ```
5. The dashboard will open in your browser at http://localhost:3001

#### Admin Dashboard
1. Open Command Prompt
2. Navigate to the admin dashboard directory:
   ```
   cd path\to\niche_plus\web_dashboards\admin
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the admin dashboard:
   ```
   npm start -- --port 3002
   ```
5. The dashboard will open in your browser at http://localhost:3002

### 2. Set Up Mobile App (Optional)
1. Open Command Prompt
2. Navigate to the mobile app directory:
   ```
   cd path\to\niche_plus\mobile_app
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Install Expo CLI globally:
   ```
   npm install -g expo-cli
   ```
5. Start the Expo development server:
   ```
   npm start
   ```
6. Use the Expo Go app on your mobile device to scan the QR code

### 3. Set Up Backend (Optional)
1. Open Command Prompt
2. Navigate to the backend directory:
   ```
   cd path\to\niche_plus\backend
   ```
3. Create a virtual environment:
   ```
   python -m venv venv
   ```
4. Activate the virtual environment:
   ```
   venv\Scripts\activate
   ```
5. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
6. Start the Flask server:
   ```
   python main.py
   ```
7. The backend API will be available at http://localhost:5000

## Troubleshooting

### Node.js Issues
- If you see "node is not recognized as an internal or external command", restart your command prompt after installation
- If npm install fails, try running Command Prompt as administrator

### Python Issues
- If you see "python is not recognized as an internal or external command", restart your command prompt after installation
- If creating a virtual environment fails, ensure you have the latest Python version

### Port Already in Use
- If a port is already in use, you can specify a different port:
  ```
  npm start -- --port 3005
  ```

## Support
If you encounter any issues, please refer to the official documentation for each tool:
- Node.js: https://nodejs.org/en/docs/
- Python: https://www.python.org/doc/
- React: https://reactjs.org/docs/
- Expo: https://docs.expo.dev/

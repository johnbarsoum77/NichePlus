from flask import Blueprint, request, jsonify
import firebase_admin
from firebase_admin import firestore
import time

admin_bp = Blueprint('admin', __name__)

# Get Firestore client (or use mock for development)
try:
    db = firestore.client()
except:
    # Mock database for development
    db = None

# Mock data for development
mock_admin_users = {
    'admin1': {
        'uid': 'admin1',
        'email': 'admin@nichemagazine.me',
        'role': 'admin',
        'name': 'Niche Admin'
    }
}

@admin_bp.route('/sectors', methods=['POST'])
def create_sector():
    """
    Create a new sector (admin only)
    """
    try:
        # Validate admin authentication (simplified for development)
        admin_id = request.headers.get('X-Admin-ID')
        if not admin_id or (admin_id not in mock_admin_users and not db):
            return jsonify({
                'success': False,
                'message': 'Unauthorized'
            }), 401
        
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('name') or not data.get('description'):
            return jsonify({
                'success': False,
                'message': 'Name and description are required'
            }), 400
            
        name = data.get('name')
        description = data.get('description')
        image_url = data.get('image_url', '')
        
        # Generate ID from name
        sector_id = name.lower().replace(' ', '-')
        
        if db:
            # Create sector in Firestore
            sector_ref = db.collection('sectors').document(sector_id)
            sector_data = {
                'id': sector_id,
                'name': name,
                'description': description,
                'image_url': image_url,
                'created_at': firestore.SERVER_TIMESTAMP,
                'created_by': admin_id
            }
            
            sector_ref.set(sector_data)
            
            return jsonify({
                'success': True,
                'message': 'Sector created successfully',
                'sector': sector_data
            }), 201
        else:
            # Create mock sector
            sector_data = {
                'id': sector_id,
                'name': name,
                'description': description,
                'image_url': image_url,
                'created_at': int(time.time()),
                'created_by': admin_id
            }
            
            # Add to mock sectors (would need to be stored in a global variable)
            
            return jsonify({
                'success': True,
                'message': 'Sector created successfully (mock)',
                'sector': sector_data
            }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@admin_bp.route('/companies', methods=['POST'])
def create_company():
    """
    Create a new company for a sector (admin only)
    """
    try:
        # Validate admin authentication (simplified for development)
        admin_id = request.headers.get('X-Admin-ID')
        if not admin_id or (admin_id not in mock_admin_users and not db):
            return jsonify({
                'success': False,
                'message': 'Unauthorized'
            }), 401
        
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('name') or not data.get('description') or not data.get('sector_id'):
            return jsonify({
                'success': False,
                'message': 'Name, description, and sector ID are required'
            }), 400
            
        name = data.get('name')
        description = data.get('description')
        sector_id = data.get('sector_id')
        why_niche_chose = data.get('why_niche_chose', '')
        logo_url = data.get('logo_url', '')
        gallery = data.get('gallery', [])
        services = data.get('services', [])
        
        # Generate ID from name
        company_id = name.lower().replace(' ', '-')
        
        if db:
            # Create company in Firestore
            company_ref = db.collection('companies').document(company_id)
            company_data = {
                'id': company_id,
                'name': name,
                'description': description,
                'sector_id': sector_id,
                'why_niche_chose': why_niche_chose,
                'logo_url': logo_url,
                'gallery': gallery,
                'services': services,
                'created_at': firestore.SERVER_TIMESTAMP,
                'created_by': admin_id
            }
            
            company_ref.set(company_data)
            
            return jsonify({
                'success': True,
                'message': 'Company created successfully',
                'company': company_data
            }), 201
        else:
            # Create mock company
            company_data = {
                'id': company_id,
                'name': name,
                'description': description,
                'sector_id': sector_id,
                'why_niche_chose': why_niche_chose,
                'logo_url': logo_url,
                'gallery': gallery,
                'services': services,
                'created_at': int(time.time()),
                'created_by': admin_id
            }
            
            # Add to mock companies (would need to be stored in a global variable)
            
            return jsonify({
                'success': True,
                'message': 'Company created successfully (mock)',
                'company': company_data
            }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@admin_bp.route('/editorial', methods=['POST'])
def create_editorial():
    """
    Create editorial content for a company (admin only)
    """
    try:
        # Validate admin authentication (simplified for development)
        admin_id = request.headers.get('X-Admin-ID')
        if not admin_id or (admin_id not in mock_admin_users and not db):
            return jsonify({
                'success': False,
                'message': 'Unauthorized'
            }), 401
        
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('company_id') or not data.get('content'):
            return jsonify({
                'success': False,
                'message': 'Company ID and content are required'
            }), 400
            
        company_id = data.get('company_id')
        content = data.get('content')
        title = data.get('title', 'Why Niche Chose This')
        
        if db:
            # Create editorial in Firestore
            editorial_ref = db.collection('editorials').document()
            editorial_data = {
                'id': editorial_ref.id,
                'company_id': company_id,
                'title': title,
                'content': content,
                'created_at': firestore.SERVER_TIMESTAMP,
                'created_by': admin_id
            }
            
            editorial_ref.set(editorial_data)
            
            return jsonify({
                'success': True,
                'message': 'Editorial content created successfully',
                'editorial': editorial_data
            }), 201
        else:
            # Create mock editorial
            editorial_id = f"editorial_{int(time.time())}"
            editorial_data = {
                'id': editorial_id,
                'company_id': company_id,
                'title': title,
                'content': content,
                'created_at': int(time.time()),
                'created_by': admin_id
            }
            
            return jsonify({
                'success': True,
                'message': 'Editorial content created successfully (mock)',
                'editorial': editorial_data
            }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

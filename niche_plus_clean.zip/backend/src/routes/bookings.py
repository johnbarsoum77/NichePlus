from flask import Blueprint, request, jsonify
import firebase_admin
from firebase_admin import firestore
import time

bookings_bp = Blueprint('bookings', __name__)

# Get Firestore client (or use mock for development)
try:
    db = firestore.client()
except:
    # Mock database for development
    db = None

# Mock data for development
mock_bookings = {}
mock_booking_id_counter = 1000

@bookings_bp.route('/', methods=['POST'])
def create_booking():
    """
    Create a new booking
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('user_id') or not data.get('company_id') or not data.get('service_id'):
            return jsonify({
                'success': False,
                'message': 'User ID, company ID, and service ID are required'
            }), 400
            
        user_id = data.get('user_id')
        company_id = data.get('company_id')
        service_id = data.get('service_id')
        booking_date = data.get('booking_date')
        notes = data.get('notes', '')
        
        if db:
            # Create booking in Firestore
            booking_ref = db.collection('bookings').document()
            booking_data = {
                'id': booking_ref.id,
                'user_id': user_id,
                'company_id': company_id,
                'service_id': service_id,
                'booking_date': booking_date,
                'notes': notes,
                'status': 'pending',
                'created_at': firestore.SERVER_TIMESTAMP
            }
            
            booking_ref.set(booking_data)
            booking_data['id'] = booking_ref.id
            
            return jsonify({
                'success': True,
                'message': 'Booking created successfully',
                'booking': booking_data
            }), 201
        else:
            # Create mock booking
            global mock_booking_id_counter
            booking_id = f"booking_{mock_booking_id_counter}"
            mock_booking_id_counter += 1
            
            booking_data = {
                'id': booking_id,
                'user_id': user_id,
                'company_id': company_id,
                'service_id': service_id,
                'booking_date': booking_date,
                'notes': notes,
                'status': 'pending',
                'created_at': int(time.time())
            }
            
            mock_bookings[booking_id] = booking_data
            
            return jsonify({
                'success': True,
                'message': 'Booking created successfully (mock)',
                'booking': booking_data
            }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@bookings_bp.route('/user/<user_id>', methods=['GET'])
def get_user_bookings(user_id):
    """
    Get all bookings for a specific user
    """
    try:
        if db:
            # Get bookings from Firestore
            bookings_ref = db.collection('bookings').where('user_id', '==', user_id)
            bookings = [doc.to_dict() for doc in bookings_ref.stream()]
            
            return jsonify({
                'success': True,
                'bookings': bookings
            }), 200
        else:
            # Return mock data
            user_bookings = [b for b in mock_bookings.values() if b['user_id'] == user_id]
            
            return jsonify({
                'success': True,
                'bookings': user_bookings
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@bookings_bp.route('/company/<company_id>', methods=['GET'])
def get_company_bookings(company_id):
    """
    Get all bookings for a specific company
    """
    try:
        if db:
            # Get bookings from Firestore
            bookings_ref = db.collection('bookings').where('company_id', '==', company_id)
            bookings = [doc.to_dict() for doc in bookings_ref.stream()]
            
            return jsonify({
                'success': True,
                'bookings': bookings
            }), 200
        else:
            # Return mock data
            company_bookings = [b for b in mock_bookings.values() if b['company_id'] == company_id]
            
            return jsonify({
                'success': True,
                'bookings': company_bookings
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@bookings_bp.route('/<booking_id>/status', methods=['PUT'])
def update_booking_status(booking_id):
    """
    Update the status of a booking
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('status'):
            return jsonify({
                'success': False,
                'message': 'Status is required'
            }), 400
            
        status = data.get('status')
        
        # Validate status
        valid_statuses = ['pending', 'confirmed', 'declined', 'completed', 'cancelled']
        if status not in valid_statuses:
            return jsonify({
                'success': False,
                'message': f'Status must be one of: {", ".join(valid_statuses)}'
            }), 400
        
        if db:
            # Update booking in Firestore
            booking_ref = db.collection('bookings').document(booking_id)
            booking_doc = booking_ref.get()
            
            if not booking_doc.exists:
                return jsonify({
                    'success': False,
                    'message': 'Booking not found'
                }), 404
                
            booking_ref.update({
                'status': status,
                'updated_at': firestore.SERVER_TIMESTAMP
            })
            
            return jsonify({
                'success': True,
                'message': 'Booking status updated successfully'
            }), 200
        else:
            # Update mock booking
            if booking_id not in mock_bookings:
                return jsonify({
                    'success': False,
                    'message': 'Booking not found'
                }), 404
                
            mock_bookings[booking_id]['status'] = status
            mock_bookings[booking_id]['updated_at'] = int(time.time())
            
            return jsonify({
                'success': True,
                'message': 'Booking status updated successfully (mock)'
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

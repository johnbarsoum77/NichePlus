from flask import Blueprint, request, jsonify
import firebase_admin
from firebase_admin import auth
import json
import time

auth_bp = Blueprint('auth', __name__)

# Mock user database for development (will be replaced with Firebase Auth)
mock_users = {}

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    Register a new user
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': 'Email and password are required'
            }), 400
            
        email = data.get('email')
        password = data.get('password')
        display_name = data.get('display_name', '')
        
        # In production, we would use Firebase Auth
        try:
            # Create user with Firebase Admin SDK
            user = auth.create_user(
                email=email,
                password=password,
                display_name=display_name
            )
            
            return jsonify({
                'success': True,
                'message': 'User registered successfully',
                'user_id': user.uid
            }), 201
            
        except Exception as e:
            # For development, fall back to mock implementation
            if 'firebase_admin' not in globals() or not firebase_admin._apps:
                # Check if user already exists in mock database
                if email in mock_users:
                    return jsonify({
                        'success': False,
                        'message': 'Email already in use'
                    }), 400
                    
                # Create mock user
                user_id = f"user_{int(time.time())}"
                mock_users[email] = {
                    'uid': user_id,
                    'email': email,
                    'password': password,  # In real app, this would be hashed
                    'display_name': display_name
                }
                
                return jsonify({
                    'success': True,
                    'message': 'User registered successfully (mock)',
                    'user_id': user_id
                }), 201
            else:
                # If Firebase is initialized but there's an error
                return jsonify({
                    'success': False,
                    'message': str(e)
                }), 400
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """
    Login a user
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': 'Email and password are required'
            }), 400
            
        email = data.get('email')
        password = data.get('password')
        
        # In production, we would use Firebase Auth
        try:
            # Get user by email (Firebase doesn't have direct email/password verification in Admin SDK)
            # This is a simplified example - in production, client would handle auth directly with Firebase
            user = auth.get_user_by_email(email)
            
            # Note: In a real app, we can't verify password server-side with Firebase Admin SDK
            # Client would use Firebase client SDK for authentication
            
            # Create custom token for the user
            custom_token = auth.create_custom_token(user.uid)
            
            return jsonify({
                'success': True,
                'message': 'Login successful',
                'token': custom_token.decode('utf-8'),
                'user_id': user.uid
            }), 200
            
        except Exception as e:
            # For development, fall back to mock implementation
            if 'firebase_admin' not in globals() or not firebase_admin._apps:
                # Check if user exists in mock database
                if email not in mock_users:
                    return jsonify({
                        'success': False,
                        'message': 'Invalid email or password'
                    }), 401
                    
                # Check password (in real app, would compare hashes)
                if mock_users[email]['password'] != password:
                    return jsonify({
                        'success': False,
                        'message': 'Invalid email or password'
                    }), 401
                    
                # Generate mock token
                mock_token = f"mock_token_{int(time.time())}"
                
                return jsonify({
                    'success': True,
                    'message': 'Login successful (mock)',
                    'token': mock_token,
                    'user_id': mock_users[email]['uid']
                }), 200
            else:
                # If Firebase is initialized but there's an error
                return jsonify({
                    'success': False,
                    'message': str(e)
                }), 401
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@auth_bp.route('/verify-token', methods=['POST'])
def verify_token():
    """
    Verify a token
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('token'):
            return jsonify({
                'success': False,
                'message': 'Token is required'
            }), 400
            
        token = data.get('token')
        
        # In production, we would use Firebase Auth
        try:
            # Verify ID token
            decoded_token = auth.verify_id_token(token)
            
            return jsonify({
                'success': True,
                'message': 'Token is valid',
                'user_id': decoded_token['uid']
            }), 200
            
        except Exception as e:
            # For development, fall back to mock implementation
            if 'firebase_admin' not in globals() or not firebase_admin._apps:
                # Check if token starts with mock prefix
                if token.startswith('mock_token_'):
                    return jsonify({
                        'success': True,
                        'message': 'Token is valid (mock)',
                        'user_id': 'mock_user_id'
                    }), 200
                else:
                    return jsonify({
                        'success': False,
                        'message': 'Invalid token'
                    }), 401
            else:
                # If Firebase is initialized but there's an error
                return jsonify({
                    'success': False,
                    'message': str(e)
                }), 401
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

from flask import Blueprint, request, jsonify
import firebase_admin
from firebase_admin import firestore
import time

users_bp = Blueprint('users', __name__)

# Get Firestore client (or use mock for development)
try:
    db = firestore.client()
except:
    # Mock database for development
    db = None

# Mock data for development
mock_users = {}

@users_bp.route('/profile/<user_id>', methods=['GET'])
def get_user_profile(user_id):
    """
    Get a user's profile
    """
    try:
        if db:
            # Get user from Firestore
            user_doc = db.collection('users').document(user_id).get()
            
            if not user_doc.exists:
                return jsonify({
                    'success': False,
                    'message': 'User not found'
                }), 404
                
            user_data = user_doc.to_dict()
            # Remove sensitive information
            if 'password' in user_data:
                del user_data['password']
            
            return jsonify({
                'success': True,
                'profile': user_data
            }), 200
        else:
            # Return mock data
            if user_id not in mock_users:
                # Create a mock profile if it doesn't exist
                mock_users[user_id] = {
                    'uid': user_id,
                    'email': f'user{user_id}@example.com',
                    'display_name': f'User {user_id}',
                    'created_at': int(time.time())
                }
            
            user_data = mock_users[user_id].copy()
            if 'password' in user_data:
                del user_data['password']
            
            return jsonify({
                'success': True,
                'profile': user_data
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@users_bp.route('/profile/<user_id>', methods=['PUT'])
def update_user_profile(user_id):
    """
    Update a user's profile
    """
    try:
        data = request.get_json()
        
        # Validate data
        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400
        
        # Remove sensitive fields that shouldn't be updated directly
        update_data = {k: v for k, v in data.items() if k not in ['uid', 'email', 'password']}
        
        if db:
            # Update user in Firestore
            user_ref = db.collection('users').document(user_id)
            user_doc = user_ref.get()
            
            if not user_doc.exists:
                return jsonify({
                    'success': False,
                    'message': 'User not found'
                }), 404
            
            update_data['updated_at'] = firestore.SERVER_TIMESTAMP
            user_ref.update(update_data)
            
            return jsonify({
                'success': True,
                'message': 'Profile updated successfully'
            }), 200
        else:
            # Update mock user
            if user_id not in mock_users:
                return jsonify({
                    'success': False,
                    'message': 'User not found'
                }), 404
            
            mock_users[user_id].update(update_data)
            mock_users[user_id]['updated_at'] = int(time.time())
            
            return jsonify({
                'success': True,
                'message': 'Profile updated successfully (mock)'
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@users_bp.route('/favorites/<user_id>', methods=['GET'])
def get_user_favorites(user_id):
    """
    Get a user's favorite companies
    """
    try:
        if db:
            # Get favorites from Firestore
            favorites_ref = db.collection('favorites').where('user_id', '==', user_id)
            favorites = [doc.to_dict() for doc in favorites_ref.stream()]
            
            return jsonify({
                'success': True,
                'favorites': favorites
            }), 200
        else:
            # Return mock data
            mock_favorites = [
                {
                    'id': 'fav1',
                    'user_id': user_id,
                    'company_id': 'exclusive-journeys',
                    'created_at': int(time.time()) - 86400
                },
                {
                    'id': 'fav2',
                    'user_id': user_id,
                    'company_id': 'luxe-stays',
                    'created_at': int(time.time())
                }
            ]
            
            return jsonify({
                'success': True,
                'favorites': mock_favorites
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@users_bp.route('/favorites/<user_id>', methods=['POST'])
def add_user_favorite(user_id):
    """
    Add a company to user's favorites
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or not data.get('company_id'):
            return jsonify({
                'success': False,
                'message': 'Company ID is required'
            }), 400
            
        company_id = data.get('company_id')
        
        if db:
            # Check if already favorited
            favorites_ref = db.collection('favorites').where('user_id', '==', user_id).where('company_id', '==', company_id)
            existing_favorites = [doc for doc in favorites_ref.stream()]
            
            if existing_favorites:
                return jsonify({
                    'success': False,
                    'message': 'Company already in favorites'
                }), 400
            
            # Add to favorites in Firestore
            favorite_ref = db.collection('favorites').document()
            favorite_data = {
                'id': favorite_ref.id,
                'user_id': user_id,
                'company_id': company_id,
                'created_at': firestore.SERVER_TIMESTAMP
            }
            
            favorite_ref.set(favorite_data)
            
            return jsonify({
                'success': True,
                'message': 'Company added to favorites',
                'favorite': favorite_data
            }), 201
        else:
            # Add to mock favorites
            favorite_id = f"fav_{int(time.time())}"
            favorite_data = {
                'id': favorite_id,
                'user_id': user_id,
                'company_id': company_id,
                'created_at': int(time.time())
            }
            
            return jsonify({
                'success': True,
                'message': 'Company added to favorites (mock)',
                'favorite': favorite_data
            }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

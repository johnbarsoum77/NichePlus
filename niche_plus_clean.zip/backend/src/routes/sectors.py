from flask import Blueprint, request, jsonify
import firebase_admin
from firebase_admin import firestore

sectors_bp = Blueprint('sectors', __name__)

# Get Firestore client (or use mock for development)
try:
    db = firestore.client()
except:
    # Mock database for development
    db = None

# Mock data for development
mock_sectors = [
    {
        'id': 'travel',
        'name': 'Travel',
        'description': 'Exclusive travel experiences curated by Niche Magazine',
        'image_url': 'https://example.com/travel.jpg'
    },
    {
        'id': 'hotels',
        'name': 'Hotels',
        'description': 'Luxury accommodations handpicked by our editors',
        'image_url': 'https://example.com/hotels.jpg'
    },
    {
        'id': 'flights',
        'name': 'Flights',
        'description': 'Premium flight services with exclusive benefits',
        'image_url': 'https://example.com/flights.jpg'
    },
    {
        'id': 'taxi',
        'name': 'Taxi',
        'description': 'Reliable and luxurious transportation services',
        'image_url': 'https://example.com/taxi.jpg'
    },
    {
        'id': 'fashion',
        'name': 'Fashion',
        'description': 'Curated fashion selections from top designers',
        'image_url': 'https://example.com/fashion.jpg'
    }
]

mock_companies = {
    'travel': {
        'id': 'exclusive-journeys',
        'name': 'Exclusive Journeys',
        'description': 'Bespoke travel experiences tailored to the discerning traveler',
        'why_niche_chose': 'Their attention to detail and personalized service is unmatched in the industry.',
        'logo_url': 'https://example.com/exclusive-journeys-logo.png',
        'gallery': [
            'https://example.com/exclusive-journeys-1.jpg',
            'https://example.com/exclusive-journeys-2.jpg',
            'https://example.com/exclusive-journeys-3.jpg'
        ],
        'services': [
            {
                'id': 'custom-itinerary',
                'name': 'Custom Itinerary Planning',
                'description': 'Personalized travel plans tailored to your preferences',
                'price': 'From $500'
            },
            {
                'id': 'private-tours',
                'name': 'Private Guided Tours',
                'description': 'Exclusive tours with expert local guides',
                'price': 'From $300 per day'
            }
        ]
    },
    'hotels': {
        'id': 'luxe-stays',
        'name': 'Luxe Stays',
        'description': 'A collection of the world\'s most exclusive boutique hotels',
        'why_niche_chose': 'Their properties offer an unparalleled blend of luxury, privacy, and authentic local experiences.',
        'logo_url': 'https://example.com/luxe-stays-logo.png',
        'gallery': [
            'https://example.com/luxe-stays-1.jpg',
            'https://example.com/luxe-stays-2.jpg',
            'https://example.com/luxe-stays-3.jpg'
        ],
        'services': [
            {
                'id': 'luxury-suite',
                'name': 'Luxury Suite',
                'description': 'Spacious suite with premium amenities',
                'price': 'From $800 per night'
            },
            {
                'id': 'private-villa',
                'name': 'Private Villa',
                'description': 'Exclusive villa with dedicated staff',
                'price': 'From $2,000 per night'
            }
        ]
    }
}

@sectors_bp.route('/', methods=['GET'])
def get_sectors():
    """
    Get all sectors
    """
    try:
        if db:
            # Get sectors from Firestore
            sectors_ref = db.collection('sectors')
            sectors = [doc.to_dict() for doc in sectors_ref.stream()]
            
            return jsonify({
                'success': True,
                'sectors': sectors
            }), 200
        else:
            # Return mock data
            return jsonify({
                'success': True,
                'sectors': mock_sectors
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@sectors_bp.route('/<sector_id>', methods=['GET'])
def get_sector(sector_id):
    """
    Get a specific sector by ID
    """
    try:
        if db:
            # Get sector from Firestore
            sector_doc = db.collection('sectors').document(sector_id).get()
            
            if not sector_doc.exists:
                return jsonify({
                    'success': False,
                    'message': 'Sector not found'
                }), 404
                
            sector = sector_doc.to_dict()
            
            return jsonify({
                'success': True,
                'sector': sector
            }), 200
        else:
            # Return mock data
            sector = next((s for s in mock_sectors if s['id'] == sector_id), None)
            
            if not sector:
                return jsonify({
                    'success': False,
                    'message': 'Sector not found'
                }), 404
                
            return jsonify({
                'success': True,
                'sector': sector
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@sectors_bp.route('/<sector_id>/company', methods=['GET'])
def get_sector_company(sector_id):
    """
    Get the recommended company for a specific sector
    """
    try:
        if db:
            # Get company from Firestore
            companies_ref = db.collection('companies').where('sector_id', '==', sector_id).limit(1)
            companies = [doc.to_dict() for doc in companies_ref.stream()]
            
            if not companies:
                return jsonify({
                    'success': False,
                    'message': 'No company found for this sector'
                }), 404
                
            company = companies[0]
            
            return jsonify({
                'success': True,
                'company': company
            }), 200
        else:
            # Return mock data
            if sector_id not in mock_companies:
                return jsonify({
                    'success': False,
                    'message': 'No company found for this sector'
                }), 404
                
            company = mock_companies[sector_id]
            
            return jsonify({
                'success': True,
                'company': company
            }), 200
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

from flask import Flask, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
import firebase_admin
from firebase_admin import credentials, firestore, auth

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Initialize Firebase (commented out until credentials are available)
# cred = credentials.Certificate('path/to/serviceAccountKey.json')
# firebase_admin.initialize_app(cred)
# db = firestore.client()

# For development, we'll use a mock initialization
if not firebase_admin._apps:
    firebase_admin.initialize_app()

# Import routes
from src.routes.auth import auth_bp
from src.routes.sectors import sectors_bp
from src.routes.bookings import bookings_bp
from src.routes.users import users_bp
from src.routes.admin import admin_bp

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(sectors_bp, url_prefix='/api/sectors')
app.register_blueprint(bookings_bp, url_prefix='/api/bookings')
app.register_blueprint(users_bp, url_prefix='/api/users')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

# Root route
@app.route('/')
def index():
    return jsonify({
        'message': 'Welcome to Niche Plus API',
        'status': 'online',
        'version': '1.0.0'
    })

# Health check route
@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy'
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)

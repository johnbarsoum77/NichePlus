# Niche Plus App - Setup Guide

## Overview

Niche Plus is a premium concierge and booking app curated by Niche Magazine. This guide will help you set up and run all components of the application locally.

## Quick Start

For Windows users, simply run the `start_niche_plus.bat` file to automatically start all components:
- Backend API server
- User Dashboard
- Company Dashboard
- Admin Dashboard
- Mobile App (Expo)

## Manual Setup Instructions

If you prefer to start components individually or are using a non-Windows system, follow these instructions:

### Prerequisites

- Python 3.11 or higher
- Node.js 16 or higher
- npm or yarn
- Expo CLI (for mobile app)

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Create and activate a virtual environment:
   ```
   # Windows
   python -m venv venv
   venv\Scripts\activate

   # macOS/Linux
   python -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Start the Flask server:
   ```
   python main.py
   ```

5. The backend will run on http://localhost:5000

### Mobile App Setup

1. Navigate to the mobile app directory:
   ```
   cd mobile_app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the Expo development server:
   ```
   npm start
   ```

4. Use the Expo Go app on your mobile device to scan the QR code, or run in a simulator

### Web Dashboards Setup

#### User Dashboard
1. Navigate to the user dashboard directory:
   ```
   cd web_dashboards/user
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start
   ```

4. The user dashboard will run on http://localhost:3000

#### Company Dashboard
1. Navigate to the company dashboard directory:
   ```
   cd web_dashboards/company
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start -- --port 3001
   ```

4. The company dashboard will run on http://localhost:3001

#### Admin Dashboard
1. Navigate to the admin dashboard directory:
   ```
   cd web_dashboards/admin
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start -- --port 3002
   ```

4. The admin dashboard will run on http://localhost:3002

## Testing

The application includes mock data for local testing. All API endpoints are functional with this mock data.

For detailed testing results, refer to the `testing_report.md` file.

## Production Deployment

For production deployment, you'll need to:

1. Set up a Firebase project and configure authentication
2. Update the Firebase configuration in the backend and frontend code
3. Deploy the backend to a cloud provider (e.g., Google Cloud Run, Heroku)
4. Build and deploy the mobile app to the App Store
5. Build and deploy the web dashboards to a web hosting service

## Project Structure

```
niche_plus/
├── backend/                  # Flask API server
├── mobile_app/               # React Native mobile app
├── web_dashboards/           # Web-based dashboards
│   ├── user/                 # User dashboard
│   ├── company/              # Company dashboard
│   └── admin/                # Admin dashboard
├── app_architecture.md       # Architecture documentation
├── testing_report.md         # Testing results
├── start_niche_plus.bat      # Windows batch file to start all components
└── setup_guide.md            # This file
```

## Support

For any questions or issues, please refer to the documentation or contact the development team.

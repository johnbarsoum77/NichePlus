import React from 'react';
import { StyleSheet, Text, View, FlatList, Image, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';

// Mock data for sectors
const mockSectors = [
  {
    id: 'travel',
    name: 'Travel',
    description: 'Exclusive travel experiences curated by Niche Magazine',
    image_url: 'https://example.com/travel.jpg'
  },
  {
    id: 'hotels',
    name: 'Hotels',
    description: 'Luxury accommodations handpicked by our editors',
    image_url: 'https://example.com/hotels.jpg'
  },
  {
    id: 'flights',
    name: 'Flights',
    description: 'Premium flight services with exclusive benefits',
    image_url: 'https://example.com/flights.jpg'
  },
  {
    id: 'taxi',
    name: 'Taxi',
    description: 'Reliable and luxurious transportation services',
    image_url: 'https://example.com/taxi.jpg'
  },
  {
    id: 'fashion',
    name: 'Fashion',
    description: 'Curated fashion selections from top designers',
    image_url: 'https://example.com/fashion.jpg'
  }
];

export default function SectorsScreen({ navigation }) {
  const renderSectorItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.sectorItem}
      onPress={() => navigation.navigate('CompanyProfile', { sectorId: item.id })}
    >
      <View style={styles.sectorContent}>
        <Text style={styles.sectorName}>{item.name}</Text>
        <Text style={styles.sectorDescription}>{item.description}</Text>
        <View style={styles.sectorArrow}>
          <Text style={styles.arrowText}>→</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Curated Sectors</Text>
        <Text style={styles.subtitle}>
          Each sector features one exclusive recommendation handpicked by our editors
        </Text>
      </View>
      
      <FlatList
        data={mockSectors}
        renderItem={renderSectorItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f5f2',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontFamily: 'System',
    fontSize: 28,
    fontWeight: '700',
    color: '#333',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'System',
    fontSize: 16,
    color: '#666',
    lineHeight: 22,
  },
  listContainer: {
    padding: 20,
  },
  sectorItem: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  sectorContent: {
    padding: 20,
  },
  sectorName: {
    fontFamily: 'System',
    fontSize: 22,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  sectorDescription: {
    fontFamily: 'System',
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
    lineHeight: 22,
  },
  sectorArrow: {
    alignItems: 'flex-end',
  },
  arrowText: {
    fontSize: 24,
    color: '#333',
  },
});

import React, { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';

// Mock data for company profile
const mockCompany = {
  id: 'exclusive-journeys',
  name: 'Exclusive Journeys',
  description: 'Bespoke travel experiences tailored to the discerning traveler. Our team of experts curates personalized itineraries that combine luxury, authenticity, and exclusivity for unforgettable journeys.',
  why_niche_chose: 'Their attention to detail and personalized service is unmatched in the industry. Each journey is meticulously crafted to provide authentic experiences while maintaining the highest standards of luxury and comfort.',
  logo_url: 'https://example.com/exclusive-journeys-logo.png',
  gallery: [
    'https://example.com/exclusive-journeys-1.jpg',
    'https://example.com/exclusive-journeys-2.jpg',
    'https://example.com/exclusive-journeys-3.jpg'
  ],
  services: [
    {
      id: 'custom-itinerary',
      name: 'Custom Itinerary Planning',
      description: 'Personalized travel plans tailored to your preferences',
      price: 'From $500'
    },
    {
      id: 'private-tours',
      name: 'Private Guided Tours',
      description: 'Exclusive tours with expert local guides',
      price: 'From $300 per day'
    },
    {
      id: 'luxury-transport',
      name: 'Luxury Transportation',
      description: 'Premium vehicles with professional drivers',
      price: 'From $200 per day'
    }
  ]
};

export default function CompanyProfileScreen({ route, navigation }) {
  const { sectorId } = route.params || { sectorId: 'travel' };
  const [selectedService, setSelectedService] = useState(null);
  
  // In a real app, we would fetch the company data based on sectorId
  const company = mockCompany;
  
  const handleBookNow = () => {
    if (selectedService) {
      navigation.navigate('Booking', { 
        companyId: company.id,
        serviceId: selectedService.id
      });
    } else {
      // Show error or prompt to select a service
      alert('Please select a service first');
    }
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <StatusBar style="light" />
      
      {/* Company Header */}
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Image 
            source={{ uri: company.logo_url }}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.companyName}>{company.name}</Text>
      </View>
      
      {/* Company Description */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>About</Text>
        <Text style={styles.description}>{company.description}</Text>
      </View>
      
      {/* Why Niche Chose This */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Why Niche Chose This</Text>
        <View style={styles.nicheNote}>
          <Text style={styles.nicheNoteText}>{company.why_niche_chose}</Text>
        </View>
      </View>
      
      {/* Services */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Services</Text>
        {company.services.map((service) => (
          <TouchableOpacity 
            key={service.id}
            style={[
              styles.serviceItem,
              selectedService?.id === service.id && styles.selectedService
            ]}
            onPress={() => setSelectedService(service)}
          >
            <View style={styles.serviceContent}>
              <View style={styles.serviceHeader}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.servicePrice}>{service.price}</Text>
              </View>
              <Text style={styles.serviceDescription}>{service.description}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
      
      {/* Book Now Button */}
      <TouchableOpacity 
        style={styles.bookButton}
        onPress={handleBookNow}
      >
        <Text style={styles.bookButtonText}>Book Now</Text>
      </TouchableOpacity>
      
      {/* Bottom Spacing */}
      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f5f2',
  },
  header: {
    backgroundColor: '#333',
    paddingTop: 60,
    paddingBottom: 30,
    alignItems: 'center',
  },
  logoContainer: {
    width: 100,
    height: 100,
    backgroundColor: '#fff',
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  logo: {
    width: 70,
    height: 70,
  },
  companyName: {
    fontFamily: 'System',
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#fff',
  },
  sectionTitle: {
    fontFamily: 'System',
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  description: {
    fontFamily: 'System',
    fontSize: 16,
    color: '#666',
    lineHeight: 24,
  },
  nicheNote: {
    backgroundColor: '#f8f5f2',
    borderRadius: 8,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#333',
  },
  nicheNoteText: {
    fontFamily: 'System',
    fontSize: 16,
    fontStyle: 'italic',
    color: '#666',
    lineHeight: 24,
  },
  serviceItem: {
    backgroundColor: '#f8f5f2',
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedService: {
    borderColor: '#333',
  },
  serviceContent: {
    padding: 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  serviceName: {
    fontFamily: 'System',
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  servicePrice: {
    fontFamily: 'System',
    fontSize: 16,
    color: '#333',
  },
  serviceDescription: {
    fontFamily: 'System',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  bookButton: {
    backgroundColor: '#333',
    margin: 20,
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  bookButtonText: {
    fontFamily: 'System',
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  bottomSpacing: {
    height: 40,
  },
});

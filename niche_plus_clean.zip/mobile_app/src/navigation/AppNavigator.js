import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Import screens
import WelcomeScreen from '../screens/WelcomeScreen';
import SectorsScreen from '../screens/SectorsScreen';
import CompanyProfileScreen from '../screens/CompanyProfileScreen';

// Create stack navigator
const Stack = createStackNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Welcome"
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: '#f8f5f2' }
        }}
      >
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="Sectors" component={SectorsScreen} />
        <Stack.Screen name="CompanyProfile" component={CompanyProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

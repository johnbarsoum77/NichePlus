# Niche Plus App Architecture

## Overview

Niche Plus is a premium concierge and booking app curated by Niche Magazine. The application consists of three main components:

1. **Mobile App** - iOS-focused React Native application for end users
2. **Web Dashboards** - Three separate web interfaces for users, companies, and administrators
3. **Backend Services** - Flask-based API with Firebase integration

This document outlines the architecture and structure of the complete application.

## Project Structure

```
niche_plus/
├── mobile_app/                  # React Native iOS application
│   ├── src/
│   │   ├── screens/             # App screens (Welcome, Sectors, Company Profile, etc.)
│   │   ├── components/          # Reusable UI components
│   │   ├── navigation/          # Navigation configuration
│   │   ├── assets/              # Images, fonts, and other static assets
│   │   ├── services/            # API services and data fetching
│   │   └── utils/               # Helper functions and utilities
│   └── __tests__/               # Unit and integration tests
│
├── web_dashboards/              # Web-based dashboards
│   ├── user/                    # User dashboard
│   │   ├── src/
│   │   │   ├── components/      # Dashboard UI components
│   │   │   ├── pages/           # Dashboard pages
│   │   │   ├── services/        # API services
│   │   │   └── utils/           # Helper functions
│   │   └── public/              # Static assets
│   │
│   ├── company/                 # Company dashboard
│   │   ├── src/
│   │   │   ├── components/      # Dashboard UI components
│   │   │   ├── pages/           # Dashboard pages
│   │   │   ├── services/        # API services
│   │   │   └── utils/           # Helper functions
│   │   └── public/              # Static assets
│   │
│   └── admin/                   # Niche admin dashboard
│       ├── src/
│       │   ├── components/      # Dashboard UI components
│       │   ├── pages/           # Dashboard pages
│       │   ├── services/        # API services
│       │   └── utils/           # Helper functions
│       └── public/              # Static assets
│
└── backend/                     # Flask backend API
    ├── src/
    │   ├── models/              # Data models
    │   ├── routes/              # API route definitions
    │   ├── services/            # Business logic services
    │   └── utils/               # Utility functions
    └── tests/                   # Backend tests
```

## Component Details

### 1. Mobile App (React Native)

The mobile app is built with React Native, focusing on iOS as the primary platform. It follows the design principles of Niche Magazine with a luxurious, minimal, editorial design.

#### Key Features:
- Welcome screen with Niche Magazine branding
- Sectors screen (Travel, Flights, Hotels, etc.)
- Company profile screen with editorial content
- Booking flow with calendar, services, and confirmation
- User dashboard with booking history and favorites

#### Technology Stack:
- React Native
- React Navigation for routing
- Firebase SDK for authentication and data fetching
- Custom UI components styled to match Niche Magazine's aesthetic

### 2. Web Dashboards (React)

Three separate web dashboards built with React for different user roles:

#### User Dashboard:
- Manage bookings
- View recommended companies
- Profile management
- Monthly Editor's Picks section

#### Company Dashboard:
- Update profile and service offerings
- Manage availability
- View and respond to bookings
- Upload gallery images

#### Admin Dashboard:
- Add/edit sectors
- Assign recommended companies
- Add editorial content
- Manage app-wide updates

#### Technology Stack:
- React
- React Router for navigation
- Material UI or custom components for UI
- Firebase SDK for authentication and data management

### 3. Backend (Flask + Firebase)

A Flask-based backend that serves as an API layer between the frontend applications and Firebase services.

#### Key Components:
- Authentication API (registration, login)
- Sectors and companies API
- Bookings management API
- User profile API
- Admin management API

#### Technology Stack:
- Flask (Python)
- Firebase Admin SDK
- Firestore for database
- Firebase Authentication

## Authentication Flow

The authentication flow follows the pattern described in the backend architecture document:

1. User registers or logs in through the mobile app or web dashboard
2. Authentication request is sent to the Flask backend
3. Backend verifies credentials with Firebase Authentication
4. Upon successful authentication, a token is returned to the client
5. Client includes this token in subsequent API requests
6. Backend verifies the token for protected endpoints

## Data Flow

1. **User Interactions:**
   - Users browse sectors and companies in the mobile app
   - Users make booking requests through the app
   - Companies respond to bookings via their dashboard
   - Admins manage content through the admin dashboard

2. **API Communication:**
   - Frontend applications communicate with the Flask backend via RESTful API calls
   - Backend processes requests and interacts with Firebase services
   - Backend returns appropriate responses to the frontend

3. **Data Storage:**
   - User profiles stored in Firestore
   - Sector and company data managed in Firestore
   - Booking information tracked in Firestore
   - Editorial content stored in Firestore

## Development Approach

The development will follow these principles:

1. **Component-Based Architecture:** Building reusable components across all platforms
2. **Separation of Concerns:** Clear separation between UI, business logic, and data access
3. **Consistent Design Language:** Following Niche Magazine's aesthetic across all platforms
4. **Responsive Design:** Ensuring web dashboards work across device sizes
5. **Local Development:** Setting up a complete local development environment for testing

## Next Steps

1. Set up the development environment for each component
2. Implement core authentication functionality
3. Develop the mobile app screens and navigation
4. Create the web dashboards with shared components
5. Implement the backend API endpoints
6. Connect all components for end-to-end testing

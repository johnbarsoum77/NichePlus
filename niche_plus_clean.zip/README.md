# Niche Plus App

A premium concierge and booking application curated by Niche Magazine.

## Overview

Niche Plus is a comprehensive booking platform that connects users with premium services across various sectors. The application consists of:

- **Mobile App**: React Native/Expo app for iOS users
- **Web Dashboards**: React-based dashboards for users, companies, and administrators
- **Backend API**: Flask-based API with Firebase integration

## Features

- User authentication and profile management
- Sector-based browsing of premium services
- Company profiles with editorial content ("Why Niche Chose This")
- Booking management for users and companies
- Administrative tools for content and user management

## Repository Structure

```
niche_plus/
├── backend/                  # Flask API server
├── mobile_app/               # React Native mobile app
├── web_dashboards/           # Web-based dashboards
│   ├── user/                 # User dashboard
│   ├── company/              # Company dashboard
│   └── admin/                # Admin dashboard
├── app_architecture.md       # Architecture documentation
├── testing_report.md         # Testing results
├── niche_plus_launcher.bat   # Windows batch file to start all components
├── niche_plus_enhanced_launcher.bat # Enhanced launcher with detailed logging
└── setup_guide.md            # Setup instructions
```

## Quick Start

For Windows users, simply run the `niche_plus_enhanced_launcher.bat` file to automatically:
- Create all necessary package.json files
- Generate minimal React app files
- Install Node.js if needed
- Start all three dashboards

## Manual Setup

If you prefer to start components individually, follow these instructions:

### Prerequisites

- Node.js 16 or higher
- npm or yarn
- Python 3.11 or higher (for backend only)

### Web Dashboards Setup

#### User Dashboard
1. Navigate to the user dashboard directory:
   ```
   cd web_dashboards/user
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start
   ```

4. The user dashboard will run on http://localhost:3000

#### Company Dashboard
1. Navigate to the company dashboard directory:
   ```
   cd web_dashboards/company
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start -- --port 3001
   ```

4. The company dashboard will run on http://localhost:3001

#### Admin Dashboard
1. Navigate to the admin dashboard directory:
   ```
   cd web_dashboards/admin
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm start -- --port 3002
   ```

4. The admin dashboard will run on http://localhost:3002

### Mobile App Setup

1. Navigate to the mobile app directory:
   ```
   cd mobile_app
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the Expo development server:
   ```
   npm start
   ```

4. Use the Expo Go app on your mobile device to scan the QR code

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Start the Flask server:
   ```
   python main.py
   ```

5. The backend will run on http://localhost:5000

## Troubleshooting

If you encounter any issues:

1. Check the logs directory for detailed error information
2. Ensure Node.js is properly installed and in your PATH
3. Try running each dashboard individually using the start_*_dashboard.bat files
4. Remember that initial startup may take 3-5 minutes as npm installs dependencies

## License

This project is proprietary and confidential. All rights reserved.

## Contact

For support or inquiries, please contact Niche Magazine.
